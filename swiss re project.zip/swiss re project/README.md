"# Code_exercise_106" 
