package com.emp.empservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.emp.empservices.service.EmployeeAnalyzer;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.net.URL;
@SpringBootTest
public class EmployeeAnalyzerTest {

    @Test
    public void testLoadEmployees() throws Exception {
    	 String filePath = "src/test/java/resources/emp.csv";
	     
     	File file=new File(filePath);
    
        EmployeeAnalyzer analyzer = new EmployeeAnalyzer();
        analyzer.loadEmployees(file.getAbsolutePath());
        assertTrue(analyzer.getEmployeeMap().size() > 0);
    }
}