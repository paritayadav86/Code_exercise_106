package com.emp.empservices.service;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import com.emp.empservices.model.Employee;

public class EmployeeAnalyzer {
	private final Map<Integer, Employee> employeeMap = new HashMap<>();
    private final Map<Integer, List<Employee>> managerToSubordinates = new HashMap<>();

    public void loadEmployees(String filePath) throws Exception {
        try (Reader reader = new FileReader(filePath)) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT
                    .withFirstRecordAsHeader()
                    .parse(reader);

            for (CSVRecord record : records) {
               // int id = Integer.parseInt(record.get("Id"));
            	 int id = Integer.parseInt(record.get(0));
                String firstName = record.get("firstName");
                String lastName = record.get("lastName");
                double salary = Double.parseDouble(record.get("salary"));
                String managerStr = record.get("managerId");
                Integer managerId = (managerStr == null || managerStr.isBlank()) ? null : Integer.parseInt(managerStr);

                Employee e = new Employee(id, firstName, lastName, salary, managerId);
                employeeMap.put(id, e);
            }

            // build map of manager → subordinates
            for (Employee e : employeeMap.values()) {
                if (e.getManagerId() != null) {
                    managerToSubordinates.computeIfAbsent(e.getManagerId(), k -> new ArrayList<>()).add(e);
                }
            }
        }
    }

    public void analyze() {
        System.out.println("==== Salary Analysis ====");
        for (Integer managerId : managerToSubordinates.keySet()) {
            Employee manager = employeeMap.get(managerId);
            List<Employee> subs = managerToSubordinates.get(managerId);
            double avgSubSalary = subs.stream().mapToDouble(Employee::getSalary).average().orElse(0);
            double minAllowed = avgSubSalary * 1.2;
            double maxAllowed = avgSubSalary * 1.5;

            if (manager.getSalary() < minAllowed) {
                System.out.printf("Manager %s earns %.2f less than minimum allowed (%.2f)%n",
                        manager.getFirstName(), (minAllowed - manager.getSalary()), minAllowed);
            } else if (manager.getSalary() > maxAllowed) {
                System.out.printf("Manager %s earns %.2f more than maximum allowed (%.2f)%n",
                        manager.getFirstName(), (manager.getSalary() - maxAllowed), maxAllowed);
            }
        }

        System.out.println("\n==== Reporting Chain Analysis ====");
        for (Employee e : employeeMap.values()) {
            int depth = getReportingDepth(e);
            if (depth > 4) {
                System.out.printf("Employee %s has %d managers above (too long by %d)%n",
                        e.getFirstName(), depth, (depth - 4));
            }
        }
    }

    private int getReportingDepth(Employee e) {
        int count = 0;
        Integer managerId = e.getManagerId();
        while (managerId != null) {
            count++;
            Employee manager = employeeMap.get(managerId);
            managerId = (manager != null) ? manager.getManagerId() : null;
        }
        return count;
    }

    public Map<Integer, Employee> getEmployeeMap() {
        return employeeMap;
    }

}
