package com.emp.empservices;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.emp.empservices.service.EmployeeAnalyzer;

@SpringBootApplication
public class EmpServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpServicesApplication.class, args);
		
		  try {
	            String filePath = "src/main/resources/emp.csv";
	     
	            	File f=new File(filePath);
	           
	            	 EmployeeAnalyzer analyzer = new EmployeeAnalyzer();
	 	            analyzer.loadEmployees(f.getAbsolutePath());
	 	           analyzer.analyze();
	             
	     
	           
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
